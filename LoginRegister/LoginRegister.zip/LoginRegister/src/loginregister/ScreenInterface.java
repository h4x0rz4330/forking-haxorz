/**
 * Author: Hardika Patel
 * File: 
 */

package loginregister;


/**
 *
 * @author hardikapatel
 */
public interface ScreenInterface {
    
    //This method will allow the injection of the Parent ScreenPane
    public void setScreenParent(ScreensController screenPage);
}
